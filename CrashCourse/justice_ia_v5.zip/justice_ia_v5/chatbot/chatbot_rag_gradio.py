import os
import pickle
import numpy as np
import gradio as gr
import openai
import faiss
from sentence_transformers import SentenceTransformer
from rank_bm25 import BM25Okapi
from dotenv import load_dotenv

# ─── Config & chargement ───────────────────────────────────────────────
load_dotenv()  # lit .env
openai.api_key = os.getenv("OPENAI_API_KEY")

# FAISS + BM25 (existants)
index = faiss.read_index("vector_store/legal_index.faiss")
with open("vector_store/id_map.pkl", "rb") as f:
    id_map = pickle.load(f)
with open("vector_store/bm25_corpus.pkl", "rb") as f:
    bm25_corpus = pickle.load(f)

bm25 = BM25Okapi(bm25_corpus)
embedder = SentenceTransformer("paraphrase-mpnet-base-v2")


# ─── Fonctions ────────────────────────────────────────────────────────
def hybrid_search(query, k_faiss=3, k_bm25=3, alpha=0.5):
    vec = embedder.encode([query]).astype("float32")
    # D, I = index.search(vec, k_faiss)
    # faiss_res = [(id_map[i]['text'], D[0][j]) for j, i in enumerate(I[0])]
    D, I = index.search(q_emb, k_faiss)
    faiss_res = [
    (id_map[idx]["text"], D[0][j], id_map[idx])
    for j, idx in enumerate(I[0])]




    tokens = query.split()
    bm25_scores = bm25.get_scores(tokens)
    bm25_res = [
        (bm25_corpus[i], bm25_scores[i])
        for i in np.argsort(bm25_scores)[::-1][:k_bm25]
    ]

    scores = {}
    for text, sc in faiss_res:
        scores[text] = alpha * (1 / (sc + 1e-6))
    for text, sc in bm25_res:
        scores[text] = scores.get(text, 0) + (1 - alpha) * sc

    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    return "\n\n".join([t for t, _ in ranked[: max(k_faiss, k_bm25)]])


def explain_law(text):
    prompt = (
        "Explique ce texte de loi de manière claire et concise :\n\n"
        f"{text}\n\n"
        "Réponse :"
    )
    resp = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
    )
    return resp.choices[0].message.content.strip()


# ─── Interfaces Gradio ────────────────────────────────────────────────
iface_search = gr.Interface(
    fn=hybrid_search,
    inputs=[
        gr.Textbox(label="Question juridique"),
        gr.Slider(1, 10, 3, label="k_faiss"),
        gr.Slider(1, 10, 3, label="k_bm25"),
        gr.Slider(0.0, 1.0, 0.5, label="alpha"),
    ],
    outputs="text",
    title="Justice IA – Recherche hybride",
    description="Combine semantique (FAISS) et mot-clé (BM25)",
)

iface_explain = gr.Interface(
    fn=explain_law,
    inputs=gr.Textbox(label="Texte de loi à expliquer", lines=5),
    outputs="text",
    title="Justice IA – Explication de loi",
    description="Fournit une explication détaillée du texte fourni",
)

demo = gr.TabbedInterface(
    [iface_search, iface_explain],
    ["Recherche", "Explication"],
)

if __name__ == "__main__":
    demo.launch(share=True)
