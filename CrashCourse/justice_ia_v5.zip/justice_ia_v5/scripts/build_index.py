# scripts/build_index.py

import os
import pickle
import pandas as pd
from sentence_transformers import SentenceTransformer
import faiss
from rank_bm25 import BM25Okapi

# ————————————————————————————————————————
# 1) CONFIGURATION DES CHEMINS
CHUNKS_CSV = "data/processed/justice_ia_chunks.csv"
VS_DIR     = "vector_store"
IDX_PATH   = os.path.join(VS_DIR, "legal_index.faiss")
MAP_PATH   = os.path.join(VS_DIR, "id_map.pkl")
BM25_PATH  = os.path.join(VS_DIR, "bm25_corpus.pkl")
# ————————————————————————————————————————

os.makedirs(VS_DIR, exist_ok=True)

# 2) LECTURE DES CHUNKS
print(f"📥 Lecture des chunks depuis `{CHUNKS_CSV}`…")
df = pd.read_csv(CHUNKS_CSV)
texts = df["chunk_text"].fillna("").astype(str).tolist()

# 3) CALCUL DES EMBEDDINGS
print("🔄 Calcul des embeddings (SentenceTransformer)…")
model = SentenceTransformer("paraphrase-mpnet-base-v2")
embeddings = model.encode(texts, convert_to_numpy=True)

# 4) CONSTRUCTION de l’INDEX FAISS
d = embeddings.shape[1]
print(f"🔧 Construction de l’IndexFlatL2 ({d} dims)…")
index = faiss.IndexFlatL2(d)
index.add(embeddings)
faiss.write_index(index, IDX_PATH)
print(f"✅ Index FAISS enregistré → `{IDX_PATH}` (n={index.ntotal})")

# 5) SAUVEGARDE de l’ID-MAP (avec le texte sous la clé "text")
print("💾 Sauvegarde de id_map (Pickle)…")
meta_df = df[[
    "doc_id","chunk_id","theme","sous_theme","titre",
    "source_url","date_publi","chunk_text"
]].rename(columns={"chunk_text":"text"})
id_map = meta_df.to_dict(orient="records")
with open(MAP_PATH, "wb") as f:
    pickle.dump(id_map, f)
print(f"✅ id_map.pkl écrit → `{MAP_PATH}`")

# 6) PRÉPARATION du corpus BM25
print("📚 Préparation du corpus BM25…")
bm25_corpus = [t.split() for t in texts]
with open(BM25_PATH, "wb") as f:
    pickle.dump(bm25_corpus, f)
print(f"✅ bm25_corpus.pkl écrit → `{BM25_PATH}`")

print("🎉 Build terminé !")
