# scripts/chunk_dataset.py

import os
import uuid
import pandas as pd
from langchain.text_splitter import RecursiveCharacterTextSplitter

# ————————————————————————————————
# 1) Chemins
SRC_CSV = "data/processed/justice_ia_dataset_final.csv"
OUT_CSV = "data/processed/justice_ia_chunks.csv"
# ————————————————————————————————

# 2) Lecture de la dataset source
print(f"📥 Lecture de `{SRC_CSV}`…")
df = pd.read_csv(SRC_CSV)

# 3) Initialisation du text splitter
#    → ~1000 caractères par chunk, chevauchement 200
splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200,
    length_function=len
)

# 4) Itération et génération des chunks
rows = []
for idx, row in df.iterrows():
    # Assure-toi d'avoir déjà identifié la bonne colonne 'contenu'
    text = str(row["contenu"])
    chunks = splitter.split_text(text)
    doc_id = str(uuid.uuid4())  # ID unique pour chaque document

    for i, chunk in enumerate(chunks, start=1):
        rows.append({
            "doc_id":     doc_id,
            "chunk_id":   f"{doc_id}_{i}",
            "theme":      row.get("theme", ""),
            "sous_theme": "",                         # à compléter manuellement si besoin
            "titre":      row.get("titre", ""),
            "source_url": row.get("source_url", ""),  # si vous avez un champ URL
            "date_publi": row.get("date_publi", ""),  # idem pour date
            "chunk_text": chunk
        })

# 5) Écriture du CSV des chunks
os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
chunks_df = pd.DataFrame(rows)
chunks_df.to_csv(OUT_CSV, index=False, encoding="utf-8")
print(f"✅ {len(chunks_df)} chunks écrits dans `{OUT_CSV}`")
