# Justice IA (v3)

Ce projet est un assistant juridique intelligent basé sur l'indexation vectorielle (FAISS) et le filtrage thématique intelligent.

## Installation et Lancement (local)

```bash
# 1. Créer un environnement virtuel
python -m venv venv
# Windows
venv\Scripts\activate
# macOS/Linux
source venv/bin/activate

# 2. Installer les dépendances
pip install -r requirements.txt

# 3. Générer l'index vectoriel
python scripts/build_index.py

# 4. Lancer le chatbot Gradio
python chatbot/chatbot_rag_gradio.py
```

## Test en ligne

Vous pouvez aussi tester dans Google Colab avec les fichiers fournis.