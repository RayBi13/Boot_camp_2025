import os
import pickle
import numpy as np
import openai
import faiss
from fastapi import FastAPI
from pydantic import BaseModel
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

app = FastAPI(title="Justice IA API")

# Chargement des index
index = faiss.read_index("vector_store/legal_index.faiss")
with open("vector_store/id_map.pkl", "rb") as f:
    id_map = pickle.load(f)
with open("vector_store/bm25_corpus.pkl", "rb") as f:
    bm25_corpus = pickle.load(f)

bm25 = BM25Okapi(bm25_corpus)
embedder = SentenceTransformer("paraphrase-mpnet-base-v2")


class Query(BaseModel):
    question: str
    k_faiss: int = 3
    k_bm25: int = 3
    alpha: float = 0.5


class ExplainRequest(BaseModel):
    text: str


@app.post("/query")
def query(q: Query):
    vec = embedder.encode([q.question]).astype("float32")
    D, I = index.search(vec, q.k_faiss)
    faiss_res = [(id_map[i]['text'], float(D[0][j])) for j, i in enumerate(I[0])]

    tokens = q.question.split()
    bm25_scores = bm25.get_scores(tokens)
    bm25_res = [
        (bm25_corpus[i], float(bm25_scores[i]))
        for i in np.argsort(bm25_scores)[::-1][: q.k_bm25]
    ]

    scores = {}
    for text, sc in faiss_res:
        scores[text] = q.alpha * (1 / (sc + 1e-6))
    for text, sc in bm25_res:
        scores[text] = scores.get(text, 0) + (1 - q.alpha) * sc

    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    return {"results": [{"text": t, "score": s} for t, s in ranked[: max(q.k_faiss, q.k_bm25)]]}


@app.post("/explain")
def explain(req: ExplainRequest):
    prompt = (
        "Explique ce texte de loi de manière claire et concise :\n\n"
        f"{req.text}\n\n"
        "Réponse :"
    )
    resp = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
    )
    return {"explanation": resp.choices[0].message.content.strip()}
